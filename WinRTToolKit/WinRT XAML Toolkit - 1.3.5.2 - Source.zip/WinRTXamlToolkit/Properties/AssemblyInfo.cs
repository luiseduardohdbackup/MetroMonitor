﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

[assembly: AssemblyTitle("WinRT XAML Toolkit")]
[assembly: AssemblyDescription("A set of controls, extensions and helper classes for Windows Runtime XAML applications.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Filip Skakun")]
[assembly: AssemblyProduct("WinRT XAML Toolkit")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.3.5.2")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguageAttribute("en")]
